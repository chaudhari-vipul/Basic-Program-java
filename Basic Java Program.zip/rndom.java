import java.util.Scanner;
class rndom 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter start number");
		int start=sc.nextInt();	
		System.out.println("Enter end  number");
		int end=sc.nextInt();
		System.out.println("which you want chack number");
		System.out.println("(1) prime");
		System.out.println("(2) palli");
		System.out.println("(3) neon");
		System.out.println("(4) even");
		System.out.println("(5) odd");
		System.out.println("(6) strong");
		System.out.println("(7) armstrong");
		System.out.println("(8) perfect");
		int num=sc.nextInt();
		while(start<end)
		{
		cases(start,num);
		start++;
		}
	}
	public static void cases(int a,int b)
	{
		switch (b)
		{
		case 1:prime(a);
		break;
		case 2:palli(a);
		break;
		case 3:neon(a);		
		break;
		case 4:even(a);		
		break;
		case 5:odd(a);		
		break;
		case 6:strong(a);		
		break;
		case 7:armstrong(a);		
		break;
		case 8:perfect(a);		
		break;
		}
	}
	public static void prime(int a)//...................................................................(1)
	{
		int i=2;
		while(a>i)
		{
			if (a%i==0)
			{
				break;
			}
			i++;
		}
		if (a==i)
		{
			System.out.println("prime=="+a);
		}
	}
	public static void palli(int num)//...................................................................(2)
	{
		int a=num;
		int rev=0;
		while (a>0)
		{
			int rem=a%10;
			rev=(rev*10)+rem;
			a/=10;
		}
		if (num==rev)
		{
			System.out.println("palli=="+num);
		}
	}
	public static void neon(int a)//...................................................................(3)
	{
		int sum=0;
		int b=a*a;
		while(b>0)
		{
			int rem=b%10;
			sum=sum+rem;
			b/=10;
		}
		if (sum==a)
		{
			System.out.println("neon=="+a);
		}
	}
	public static void even(int a)//...................................................................(4)
	{
		if (a%2==0)
		{
			System.out.println("even number=="+a);
		}
	}
	public static void odd(int a)//...................................................................(5)
	{
		if (a%2==1)
		{
			System.out.println("odd number=="+a);
		}
	}
	public static void strong(int num)//...................................................................(6)
	{
		int a=num;
		int sum=0;
		while(a>0)
		{
			int rem=a%10;
			sum=sum+fact(rem);
			a/=10;
		}
		if (sum==num)
		{
			System.out.println("strong number=="+num);
		}
	}
	public static int fact(int a)
	{
		int fact=1;
		while(a>0)
		{
			fact=fact*a;
			a--;
		}
		return fact;
	}
	public static void armstrong(int num)//...................................................................(7)
	{
		int sum=arm(num);
		if (sum==num)
		{
			System.out.println("Armstrong number"+sum);
		}
		
	}
	public static int arm(int num)
	{
		int count=digit(num);
		int sum=0;
		while(num>0)
		{
			int rem=num%10;
			sum=sum+power(rem,count);
			num/=10;
		}
		return sum;
	}
		public static int digit(int a)
	{
			int count=0;
			while(a>0)
		{
				count++;
				a/=10;
		}
		return count;
	}
	public static int power(int base,int pwr)
	{
		int sum=1;
		while (pwr>0)
		{
			sum=sum*base;
			pwr--;
		}
		return sum;
	}
	public static void perfect(int a)//...................................................................(8)
	{
		int sum=0;
		for (int i=1;i<a;i++)
		{
			if (a%i==0)
			{
				sum=sum+i;
			}
		}
		if(a==sum)
		{
			System.out.println("perfect number=="+sum);
		}
	}
}